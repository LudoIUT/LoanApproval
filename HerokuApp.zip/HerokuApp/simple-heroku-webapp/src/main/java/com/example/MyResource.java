package com.example;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.PathParam;
import javax.ws.rs.FormParam;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.io.OutputStreamWriter;
import javax.ws.rs.client.ClientBuilder;
import org.json.*;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("myresource")
public class MyResource {

    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getIt() {
        return "Hello, Heroku!";
    }

    @Path("/askCredit")
    @POST
    @Produces(MediaType.TEXT_HTML)
    public String ask_credit(@FormParam("name") String name, @FormParam("sum") String sum) throws JSONException {
        
        JSONObject jsnobject = null;
        JSONArray jsonArray = null;
        String response = "", responseResult = "", risk = null;
        int j = 0, i = 0, amount = 0, sumInt = Integer.parseInt(sum);
        try{
            response = ClientBuilder.newClient().target("http://1-dot-robust-resource-130621.appspot.com/accManager/account/getAccount").request().get(String.class);
        }
        catch(Exception exc){
            return "There is a problem with the accManager communication.";
        }
        jsnobject = new JSONObject(response);
        jsonArray = jsnobject.getJSONArray("accounts");
        for (i = 0; i < jsonArray.length(); i++) 
        {                    
                if(jsonArray.getJSONObject(i).getString("LastName").equals(name))
                {
                    risk = jsonArray.getJSONObject(i).getString("Risk");
                    amount = Integer.parseInt(jsonArray.getJSONObject(i).getString("Account"));
                    break;
                }
        }
        if(sumInt < 10000)
        {       
            if(risk == null)
            {
                return "There is a problem with the bank account (No risk)";
            }
            else if(risk.equals("high"))
            {
                return appManager(response, jsnobject, jsonArray, i, responseResult, amount, sumInt, name);
            }
            else
            {
                return updateAccount(name, amount, sumInt);
            }
        }
        else{
            return appManager(response, jsnobject, jsonArray, i, responseResult, amount, sumInt, name);
        }
    }

    public String appManager(String response, JSONObject jsnobject, JSONArray jsonArray, int i, String responseResult, int amount, int sumInt, String name) throws JSONException 
    {
        response = ClientBuilder.newClient().target("http://1-dot-robust-resource-130621.appspot.com/appManager/approval/getApprovals").request().get(String.class);
            
        jsnobject = new JSONObject(response);
        jsonArray = jsnobject.getJSONArray("approvals");
        for (i = 0; i < jsonArray.length(); i++) 
        {                    
                if(jsonArray.getJSONObject(i).getString("Name").equals(name))
                {
                    responseResult = jsonArray.getJSONObject(i).getString("Response");
                    break;
                }
        }

        if(responseResult == null)
        {
            return "There is a problem with the approval (No response)";
        }
        else if(responseResult.equals("accepted"))
        {
            return updateAccount(name, amount, sumInt);
        }
        else
            return "refused";
    }

    public String updateAccount(String name, int amount, int sumInt)
    {
        try
        {
            amount += sumInt;
            URL url = new URL("http://1-dot-robust-resource-130621.appspot.com/accManager/account/updateAccount/"+name+"/"+amount);
            HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();
            httpCon.setDoOutput(true);
            httpCon.setRequestMethod("PUT");
            OutputStreamWriter out = new OutputStreamWriter(
                httpCon.getOutputStream());
            out.write("Resource content");
            out.close();
            httpCon.getInputStream();
        }
        catch(Exception e)
        {
            return "Invalid communication with the accManager web service.";
        }
        return "approved";
    }
}
